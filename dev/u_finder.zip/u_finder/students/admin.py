from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(Level)
admin.site.register(Student)
admin.site.register(Degree)
admin.site.register(University)
admin.site.register(Suggestion)
admin.site.register(univDegree)
admin.site.register(Topics)
admin.site.register(Courses)
admin.site.register(University_Info)
admin.site.register(DonationInfo)
